var APP_DATA = {
  "scenes": [
    {
      "id": "0-master-bedroom",
      "name": "MASTER BEDROOM",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "1-salacocina",
      "name": "SALA/COCINA",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.08098970711319176,
          "pitch": 0.11292992642847999,
          "rotation": 0,
          "target": "2-deck-exterior"
        },
        {
          "yaw": 3.0343726638435697,
          "pitch": 0.2373381578725713,
          "rotation": 0,
          "target": "3-garden"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-deck-exterior",
      "name": "DECK EXTERIOR",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "3-garden",
      "name": "GARDEN",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.05606333126604035,
          "pitch": 0.49063999045892714,
          "rotation": 0,
          "target": "1-salacocina"
        },
        {
          "yaw": 2.9511450148624085,
          "pitch": 0.40139152608731266,
          "rotation": 0,
          "target": "4-acceso"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-acceso",
      "name": "ACCESO",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.2618400982144773
      },
      "linkHotspots": [
        {
          "yaw": -0.1881112123136539,
          "pitch": 0.14052397796270455,
          "rotation": 0,
          "target": "3-garden"
        },
        {
          "yaw": 1.1297026542686197,
          "pitch": 0.09118624573742196,
          "rotation": 1.5707963267948966,
          "target": "0-master-bedroom"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "CASA GH ",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
